import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files


// Set up parent class for books
public class Books {
	int isbn;
	String title;
	String language;
	String genre;
	String releaseDate;
	double retailPrice;
	int quantity;
	
	
	public static void main(String[] args) {

	}

}

// Set up children classes that inherit from the parent
class Paperback extends Books {
	int pages;
	String condition;
	// Constructors which pass value through to them
	public Paperback(int isbn, String title, String language, String genre, String releaseDate, double retailPrice, int quantity, int pages, String condition) {
}

class Ebook extends Books {
	int pages;
	String format;
	public Ebook(int isbn, String title, String language, String genre, String releaseDate, double retailPrice, int quantity, int pages, String format) {
		
	}
}

class Audiobook extends Books {
	double duration;
	String format;
	public Audiobook(int isbn, String title, String language, String genre, String releaseDate, double retailPrice, int quantity, String duration, String format) {
	}
}
}