
public class Main {

	public static void main(String[] args) {
		loginFrame loginFrame = new loginFrame();
		loginFrame.main(null);  
		

	}

}
